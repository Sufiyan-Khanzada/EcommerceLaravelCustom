

 <!--Plugins-->
 <script src="{{asset('js/jquery.js')}}"></script>
    <script src="{{asset('js/plugins.js')}}"></script>
    <script src="{{asset('js/jquery.mask.min.js')}}"></script>

    <!--Template functions-->
    <script src="{{asset('js/functions.js')}}"></script>
    <script src="{{asset('js/custom.js')}}"></script>