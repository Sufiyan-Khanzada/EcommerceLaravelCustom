<?php
    ini_set("soap.wsdl_cache_enabled", "0");
    error_reporting(15);
    set_time_limit(1000);   //seconds
?>