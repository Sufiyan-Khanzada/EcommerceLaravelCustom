<!DOCTYPE html>
<html lang="en" id="html-mode" >
  <head>
    
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!--Any config settings you want to fetch you will get in $config array, -->
    <?php //echo $config['COMPANY']; ?>
    <title><?php echo e(isset($title)?$title:''); ?></title>
    <link rel="shortcut icon" href="<?php echo e(asset('assets/images/favicon.ico')); ?>" type="image/x-icon">
    <link rel="apple-touch-icon" href="<?php echo e(asset('assets/images/apple-touch-icon.png')); ?>">
  
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <?php echo $__env->make('layouts.links', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('css'); ?>
  </head>
  <body >
    
    <input type="hidden" id="web_base_url" value="<?php echo e(url('/')); ?>"/>
    <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
    <?php echo $__env->yieldContent('content'); ?>
    <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
    <?php echo $__env->make('layouts.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('js'); ?>
    <script type="text/javascript">
(()=>{
  

		<?php if(session('notify_success')): ?>
		$.toast({
				heading: 'Success!',
				position: 'bottom-right',
				text:  '<?php echo e(session('notify_success')); ?>',
				loaderBg: '#ff6849',
				icon: 'success',
				hideAfter: 2000,
				stack: 6
			});
      <?php elseif(session('notify_error')): ?>
      $.toast({
						heading: 'Error!',
						position: 'bottom-right',
						text:  '<?php echo e(session('notify_error')); ?>',
						loaderBg: '#ff6849',
						icon: 'error',
						hideAfter: 2000,
						stack: 6
					});
        <?php endif; ?>



})()
    </script>
    <?php echo $__env->make('layouts.errorhandler', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  
  </body>
  <div id="preloader" style="display:none;">  
    <div class="loading">
        <span>Loading...</span>
    </div>
    
</html><?php /**PATH C:\laragon\www\ecomapp\resources\views/layouts/main.blade.php ENDPATH**/ ?>