

 <!--Plugins-->
 <script src="<?php echo e(asset('js/jquery.js')); ?>"></script>
    <script src="<?php echo e(asset('js/plugins.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery.mask.min.js')); ?>"></script>

    <!--Template functions-->
    <script src="<?php echo e(asset('js/functions.js')); ?>"></script>
    <script src="<?php echo e(asset('js/custom.js')); ?>"></script><?php /**PATH C:\laragon\www\ecomapp\resources\views/layouts/scripts.blade.php ENDPATH**/ ?>